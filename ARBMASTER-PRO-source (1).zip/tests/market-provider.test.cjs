const {test}=require('node:test');
const assert=require('node:assert/strict');
require('../dist/math.js');
require('../dist/market.js');
require('../dist/provider.js');
test('Unknown rules, extra markets and mismatched overtime never verify',()=>{
  assert.equal(ArbMarket.checkMarket({coverage:false},2).ok,false);
  const rules=[ArbMarket.ruleKeys.map(()=> 'same'),ArbMarket.ruleKeys.map(()=> 'same')];
  assert.equal(ArbMarket.checkMarket({coverage:true,rules},2).ok,true);
  rules[1][5]='different';
  assert.match(ArbMarket.checkMarket({coverage:true,rules},2).message,/Overtime/);
  assert.equal(ArbMarket.checkMarket({coverage:true,rules,complex:true},2).ok,false);
});
test('Provider normalization separates draw coverage and refuses stale quotes',()=>{
  const now=Date.parse('2026-11-22T00:00:00Z');
  const market=(h,a,draw,last=now)=>({key:'h2h',last_update:new Date(last).toISOString(),outcomes:[{name:'Home',price:h},{name:'Away',price:a},...(draw?[{name:'Draw',price:draw}]:[])]});
  const e={id:'one',home_team:'Home',away_team:'Away',commence_time:new Date(now+3600000).toISOString(),sport_title:'Football',bookmakers:[
    {key:'a',markets:[market(2.2,1.8),market(2.1,4.2,3.6)]},
    {key:'b',markets:[market(1.8,2.2),market(1.8,6.0,3,now-400000)]}
  ]};
  const result=ArbProvider.normalize([e],'us',now);
  assert.equal(result.length,1);assert.equal(result[0].legs.length,2);assert.equal(result[0].legs[1].odds,'2.2');
  assert.equal(ArbProvider.normalize([e],'us',now+301000).length,0);
});
test('Provider client normalizes network, rate limit and unconfigured errors',async()=>{
  await assert.rejects(ArbProvider.request('/api/odds',async()=>{throw Error('network')}),/unreachable/);
  await assert.rejects(ArbProvider.request('/api/odds',async()=>({status:429})),/limit/);
  await assert.rejects(ArbProvider.request('/api/odds',async()=>({status:503})),/unconfigured/);
});
test('Server adapter caches requests, handles unavailable provider and validates input',async()=>{
  const {createOddsAdapter}=await import('../scripts/server.mjs');
  const url=new URL('https://test.example/api/odds?sport=soccer_epl&region=uk');
  assert.equal((await createOddsAdapter()(url)).status,503);
  let calls=0;
  const adapter=createOddsAdapter({apiKey:'test',fetcher:async url=>{calls++;assert.equal(url.hostname,'api.the-odds-api.com');assert.equal(url.searchParams.get('oddsFormat'),'decimal');return {ok:true,json:async()=>[]}}});
  assert.equal((await adapter(url)).status,200);assert.equal((await adapter(url)).status,200);assert.equal(calls,1);
  assert.equal((await adapter(new URL('https://test.example/api/odds?sport=bad!&region=eu'))).status,400);
  const failure=createOddsAdapter({apiKey:'test',fetcher:async()=>{throw Error()}});
  assert.equal((await failure(url)).status,502);
});
test('Required test cases continue to hold for different currency increments',()=>{
  const r=ArbMath.arbitrate({budget:'1000',rows:['2.10','3.60','4.20'].map(odds=>({odds})),minor:'1',increment:'10'});
  assert.equal(r.cost,ArbMath.parse('1000'));assert.equal(r.worst,ArbMath.parse('8'));
});
