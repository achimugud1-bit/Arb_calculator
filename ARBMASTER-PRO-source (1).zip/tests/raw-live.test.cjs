const {test}=require('node:test');
const assert=require('node:assert/strict');
const {mkdtemp,readFile,rm}=require('node:fs/promises');
const {join}=require('node:path');
const {tmpdir}=require('node:os');

const clock=Date.parse('2026-11-22T00:00:00.000Z');
const iso=n=>new Date(n).toISOString();
const slugs=['sportybet-test','bet9ja-test'];
function definition(id,marketName,marketType,handicap,labels,period='fulltime'){
  return {marketId:id,marketName,marketType,handicap,period,sportId:10,playerProp:false,
    outcomes:labels.map((outcomeName,i)=>({outcomeName,outcomeId:id*10+i}))};
}
const result=definition(101,'Full Time Result','1x2',0,['1','X','2']);
const total=definition(106,'Over Under Full Time','totals',2.5,['Over','Under']);
const firstHalf=definition(108,'Over Under Full Time','totals',2.5,['Over','Under'],'firsthalf');
const push=definition(109,'Over Under Full Time','totals',2,['Over','Under']);
function market(m,prices){
  return {marketActive:true,outcomes:Object.fromEntries(m.outcomes.map(({outcomeId},i)=>[outcomeId,{players:{0:{
    active:true,price:prices[i],changedAt:iso(clock-30000),bookmakerChangedAt:null,limit:null
  }}}]))};
}
function fixture(bookIndex,resultOdds,totalOdds){
  return {fixtureId:'example',sportId:10,tournamentId:17,tournamentName:'Example league',
    participant1Id:101,participant2Id:102,participant1Name:'Example home',participant2Name:'Example away',
    statusId:0,hasOdds:true,startTime:iso(clock+3600000),bookmakerOdds:{[slugs[bookIndex]]:{
      bookmakerIsActive:true,suspended:false,markets:{
        101:market(result,resultOdds),106:market(total,totalOdds),
        108:market(firstHalf,[9,9]),109:market(push,[9,9])
      }
    }}};
}
function raw(){
  return {now:clock,slugs,markets:[result,total,firstHalf,push],
    boards:[[fixture(0,[2.5,3.8,2.7],[2.2,1.8])],[fixture(1,[1.9,3.1,4.2],[1.8,2.1])]]};
}
test('Independent scanner discovers two- and three-way cross-book opportunities',async()=>{
  const {scanRawOdds}=await import('../scripts/live-games.mjs');
  const scanned=scanRawOdds(raw());
  assert.equal(scanned.matched,1);
  const three=scanned.opportunities.find(o=>o.market==='Full-time result'&&o.legs[0].odds==='2.5'&&o.legs[2].odds==='4.2');
  const two=scanned.opportunities.find(o=>o.market==='Full-time goals · 2.5');
  assert.deepEqual(three.legs.map(l=>l.book),['SportyBet','SportyBet','Bet9ja']);
  assert.deepEqual(two.legs.map(l=>l.odds),['2.2','2.1']);
  assert.ok(scanned.opportunities.every(o=>o.group.endsWith('-101')||o.group.endsWith('-106')));
  assert.doesNotThrow(()=>JSON.stringify(scanned));
});
test('Scanner rejects mismatched starts, teams and lines, suspended books and stale quotes',async()=>{
  const {scanRawOdds}=await import('../scripts/live-games.mjs');
  const right=r=>r.boards[1][0].bookmakerOdds[slugs[1]];
  for(const change of [
    r=>r.boards[1][0].participant1Id=999,
    r=>r.boards[1][0].startTime=iso(clock+4000000),
    r=>right(r).suspended=true,
    r=>{right(r).markets[101].marketActive=false;right(r).markets[110]=right(r).markets[106];delete right(r).markets[106];},
    r=>Object.values(right(r).markets).forEach(m=>Object.values(m.outcomes).forEach(o=>o.players[0].changedAt=iso(clock-310000)))
  ]){
    const r=raw();change(r);
    assert.deepEqual(scanRawOdds(r).opportunities,[]);
  }
});
test('Requests are shared, limited to seven persisted calls per day, and never expose the key',async()=>{
  const {createLiveGames}=await import('../scripts/live-games.mjs');
  const dir=await mkdtemp(join(tmpdir(),'arb-quota-'));
  try{
    let now=clock;
    const calls=[];
    const r=raw();
    const config={apiKey:'test-key',slugs,quotaPath:join(dir,'quota.json'),now:()=>now,wait:async()=>{},
      fetcher:async url=>{
        calls.push(url.pathname);
        assert.equal(url.searchParams.get('apiKey'),'test-key');
        return {ok:true,json:async()=>url.pathname.endsWith('/markets')?r.markets:r.boards[slugs.indexOf(url.searchParams.get('bookmaker'))]};
      }};
    const scan=createLiveGames(config);
    const [a,b]=await Promise.all([scan(),scan()]);
    assert.equal(a.status,'ready');
    assert.equal(a,b);
    assert.equal(calls.length,3);
    assert.doesNotMatch(JSON.stringify(a),/test-key/);
    now+=300000;await scan();
    now+=300000;await scan();
    assert.equal(calls.length,7);
    const blocked=await createLiveGames(config)();
    assert.equal(blocked.status,'quota_paused');
    assert.ok(blocked.nextScan>now);
    assert.equal(calls.length,7);
    assert.equal(JSON.parse(await readFile(config.quotaPath,'utf8')).length,7);
    assert.equal((await createLiveGames()()).status,'unconfigured');
  }finally{await rm(dir,{recursive:true,force:true});}
});
test('Node Live Games route handles missing coverage and rejects cross-site triggers',async()=>{
  const {createAppServer}=await import('../scripts/server.mjs');
  const request=createAppServer().listeners('request')[0];
  async function simulate(headers){
    const response={};
    await request({url:'/api/live-games',method:'GET',headers},{
      setHeader(){},writeHead(status,headers){Object.assign(response,{status,headers});},
      end(body){response.body=body;}
    });
    return response;
  }
  const res=await simulate({});
  assert.equal(res.status,200);
  assert.equal(res.headers['Cache-Control'],'no-store');
  assert.equal(JSON.parse(res.body).status,'unconfigured');
  assert.equal((await simulate({'sec-fetch-site':'cross-site'})).status,403);
});
