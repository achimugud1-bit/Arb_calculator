const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
function openWorkspace(stored=new Map(),protocol='file:'){
  const nodes=new Map(),listeners=new Map(),windowListeners=new Map();
  const create=()=>({innerHTML:'',textContent:'',classList:{toggle(){},add(){},remove(){}},dataset:{},hidden:true,focus(){},setAttribute(){}});
  const node=id=>{if(!nodes.has(id))nodes.set(id,create());return nodes.get(id)};
  const ctx=vm.createContext({
    document:{querySelector:node,querySelectorAll:()=>[],addEventListener:(k,v)=>listeners.set(k,v),body:create(),documentElement:create()},
    localStorage:{getItem:k=>stored.get(k),setItem:(k,v)=>stored.set(k,v)},
    location:{hash:'',protocol},window:{addEventListener:(k,v)=>windowListeners.set(k,v),setInterval(){},scrollTo(){}},
    navigator:{},Intl,structuredClone,setTimeout,clearTimeout,console
  });
  const html=fs.readFileSync(require.resolve('../dist/arbmaster-pro-offline.html'),'utf8');
  const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  assert.equal(scripts.length,4);
  for(const [i,m] of scripts.entries())vm.runInContext(m[1],ctx,{filename:'offline-inline-'+i+'.js'});
  return {node,ctx,stored,eval:code=>vm.runInContext(code,ctx),listeners,windowListeners};
}
test('Standalone boot, calculator routes, invalid input and state restoration',()=>{
  const w=openWorkspace();
  assert.match(w.node('#main').innerHTML,/Enter odds/);
  assert.match(w.node('#result-body').innerHTML,/493\.95/);
  w.eval("state.rows[0].odds='invalid';renderArb()");
  assert.match(w.node('#result-body').innerHTML,/valid non-negative number/);
  w.eval("state.rows[0].odds='2.20';state.rows[1].odds='2.20';state.budget='100';renderArb();set('calc',state)");
  assert.match(w.node('#result-body').innerHTML,/10\.00%/);
  assert.match(openWorkspace(w.stored).node('#result-body').innerHTML,/10\.00%/);
  const links=markup=>[...markup.matchAll(/href="#([^"]+)"/g)].map(match=>match[1]);
  for(const nav of ['#sidebar','#mobile-nav']){
    const markup=w.node(nav).innerHTML.replace(/<a href="#arbitrage" class="brand">.*?<\/a>/,'');
    assert.deepEqual(links(markup),['arbitrage','live','tracker','money']);
  }
  for(const [route,title] of [['live','Live Games'],['tracker','Tracker'],['money','Money Tracker']]){
    w.eval("location.hash='#"+route+"';render()");
    assert.ok(w.node('#main').innerHTML.includes('<h1>'+title+'</h1>'));
  }
  for(const route of ['dashboard','backlay','advanced','bankroll','history','settings','constructor']){
    w.eval("location.hash='#"+route+"';render()");
    assert.match(w.node('#main').innerHTML,/<h1>Arbitrage Calculator<\/h1>/);
  }
  const calculator=w.node('#main').innerHTML;
  for(const attr of ['data-action="reverse"','data-bind="currency"']){
    assert.equal(calculator.split(attr).length-1,1);
  }
  assert.equal(w.node('#result-body').innerHTML.split('data-action="copy-stake"').length-1,2);
});
test('Currency outputs preserve minor units and large exact amounts',()=>{
  const w=openWorkspace();
  for(const [code,value,expected] of [['NGN','1234.56','₦1,234.56'],['USD','1234.56','$1,234.56'],['GBP','1234.56','£1,234.56'],['EUR','1234.56','€1,234.56'],['JPY','-1234','-¥1,234'],['USD','99999999999999999999.99','$99,999,999,999,999,999,999.99']]){
    assert.equal(w.eval(`money(M.parse('${value}','Amount',true),'${code}')`),expected);
  }
});
test('Fast bulk input distinguishes labeled and ambiguous text and caps outcomes',()=>{
  const w=openWorkspace();
  for(const value of ['2.15 2.05','2.1,3.6,4.2','2.10 / 3.60 / 4.20']){
    assert.equal(w.eval(`bulkParse(${JSON.stringify(value)}).ambiguous`),false);
  }
  assert.equal(w.eval("bulkParse('Book A: 2.15\\nBook B: 2.05').rows[1].book"),'Book B');
  assert.equal(w.eval("bulkParse('Home at 2.15 and away at 2.05').ambiguous"),true);
  assert.throws(()=>w.eval("bulkParse('2 2 2 2 2 2 2')"));
});
test('Existing bet records are preserved and pending payouts stay hidden',()=>{
  const stored=new Map([['arbmaster.v1.bets',JSON.stringify([
    {id:'one',event:'Settled event',selection:'A',currency:'NGN',status:'Won',stake:'100',odds:'2.2',payout:'220',fee:'2',date:'2026-01-02'},
    {id:'two',event:'Pending event',selection:'B',currency:'USD',status:'Pending',stake:'100',odds:'2.2',payout:'999',date:'2026-01-02'}
  ])]]);
  const w=openWorkspace(stored);
  w.eval("location.hash='#tracker';render()");
  assert.match(w.node('#bet-list').innerHTML,/Settled event/);
  assert.match(w.node('#bet-list').innerHTML,/₦118\.00/);
  assert.match(w.node('#bet-list').innerHTML,/Pending event/);
  assert.doesNotMatch(w.node('#bet-list').innerHTML,/999/);
  assert.equal(JSON.parse(stored.get('arbmaster.v1.bets')).length,2);
});
test('Legacy custom 2- and 3-way selections open in their dedicated mode',()=>{
  for(const count of [2,3]){
    const w=openWorkspace(new Map([['arbmaster.v1.calc',JSON.stringify({mode:'custom',count})]]));
    assert.equal(w.eval('state.mode'),String(count));
    assert.equal(w.eval('count()'),count);
  }
});
test('Live demo prices transfer to the calculator and keep selections associated',async()=>{
  const w=openWorkspace();
  const click=(action,value)=>w.listeners.get('click')({target:{closest:()=>({dataset:{action,value}})}});
  w.eval("location.hash='#live';render()");
  assert.match(w.node('#main').innerHTML,/DEMO DATA/);
  assert.match(w.node('#live-results').innerHTML,/data-action="live-open"/);
  await click('live-open','demo-1');
  assert.equal(w.eval('location.hash'),'arbitrage');
  w.windowListeners.get('hashchange')();
  const original=w.eval('JSON.stringify(state.rows.slice(0,2))');
  await click('reverse');
  assert.deepEqual(JSON.parse(w.eval('JSON.stringify(state.rows.slice(0,2))')),JSON.parse(original).reverse());
});
test('Money Tracker restores old cash activity, reserves open funds and isolates currencies',()=>{
  const stored=new Map([
    ['arbmaster.v1.moves',JSON.stringify([{id:'bank',kind:'Initial bankroll',currency:'NGN',amount:'1000',date:'2026-01-01'}])],
    ['arbmaster.v1.bets',JSON.stringify([
      {status:'Won',currency:'NGN',stake:'100',payout:'220',fee:'2'},
      {status:'Pending',currency:'NGN',stake:'100',liability:'20',fee:'1',payout:'999'},
      {status:'Draft',currency:'NGN',stake:'1000'},
      {status:'Pending',currency:'USD',stake:'500'}
    ])]
  ]);
  const w=openWorkspace(stored);
  w.eval("location.hash='#money';render()");
  assert.match(w.node('#main').innerHTML,/₦997\.00/);
  assert.match(w.node('#main').innerHTML,/₦121\.00/);
  assert.match(w.node('#main').innerHTML,/Initial bankroll/);
  assert.throws(()=>w.eval("addCashMovement('Initial bankroll','10','NGN')"),/already exists/);
  assert.throws(()=>w.eval("addCashMovement('Withdrawal','998','NGN')"),/exceeds/);
  assert.throws(()=>w.eval("addCashMovement('Deposit','0.001','NGN')"),/minor unit/);
  w.eval("addCashMovement('Withdrawal','200','NGN');addCashMovement('Deposit','50','USD')");
  const restored=openWorkspace(stored);
  assert.equal(restored.eval("M.str(moneyAccount('NGN').available)"),'797.00');
  assert.equal(restored.eval("M.str(moneyAccount('USD').available)"),'-450.00');
});
test('Locked whole-number stakes calculate and copy only the selected bookmaker amount',async()=>{
  const w=openWorkspace();
  assert.match(w.node('#main').innerHTML,/Lock a stake/);
  w.eval("state.rows[0].fixed='5000';state.rows[1].book='Book B';state.budget='';renderArb()");
  assert.match(w.node('#result-body').innerHTML,/₦5,244/);
  assert.match(w.node('#result-body').innerHTML,/Copy stake for Outcome B at Book B/);
  assert.equal(w.eval('current.unused'),null);
  const copied=[];
  w.ctx.navigator.clipboard={writeText:async text=>copied.push(text)};
  await w.listeners.get('click')({target:{closest:()=>({dataset:{action:'copy-stake',value:'1'}})}});
  assert.deepEqual(copied,['5244']);
  w.eval("state.increment='0.1';renderArb()");
  assert.match(w.node('#result-body').innerHTML,/whole-number stake increment/);
  w.eval("state.increment='1';state.rows[0].fixed='5000.50';renderArb()");
  assert.equal(w.eval('current'),null);
});
test('Quick Mode groups each stake with its odds and shares state with the full calculator',async()=>{
  const w=openWorkspace();
  const click=(action,value)=>w.listeners.get('click')({target:{closest:()=>({dataset:{action,value}})}});
  const edit=(dataset,value)=>w.listeners.get('input')({type:'input',target:{type:'text',dataset,value}});
  await click('quick');
  const markup=w.node('#main').innerHTML;
  assert.match(markup,/<h1>Quick Arbitrage<\/h1>/);
  assert.equal(markup.split('class="quick-outcome"').length-1,2);
  assert.doesNotMatch(markup,/Outcome breakdown|Stake limits/);
  assert.equal(w.node('#quick-stake-0').placeholder,'4881');
  assert.equal(w.node('#quick-stake-kind-0').textContent,'Auto');
  assert.equal(w.node('#quick-stake-1').placeholder,'5119');
  assert.match(w.node('#quick-summary').innerHTML,/493\.95/);
  edit({bind:'budget'},'');
  edit({row:'fixed',index:'0'},'5000');
  assert.equal(w.node('#main').innerHTML,markup);
  assert.equal(w.node('#quick-stake-1').placeholder,'5244');
  assert.equal(w.node('#quick-stake-kind-0').textContent,'Locked');
  const copied=[];
  w.ctx.navigator.clipboard={writeText:async text=>copied.push(text)};
  await click('copy-stake','1');
  assert.deepEqual(copied,['5244']);
  edit({row:'odds',index:'1'},'');
  assert.equal(w.node('#quick-stake-1').placeholder,'—');
  assert.equal(w.node('.quick-copy[data-value="1"]').disabled,true);
  edit({row:'odds',index:'1'},'2.05');
  assert.equal(w.node('.quick-copy[data-value="1"]').disabled,false);
  await click('quick');
  assert.match(w.node('#main').innerHTML,/Outcome breakdown/);
  assert.match(w.node('#result-body').innerHTML,/5,244/);
});
test('Android content downloads show demo data without trying a live API',async()=>{
  const w=openWorkspace(new Map(),'content:');
  w.eval("location.hash='#live';render();scanVisibleLive()");
  const page=w.node('#main').innerHTML;
  assert.match(page,/You opened the offline download/);
  assert.match(page,/DEMO DATA/);
  assert.doesNotMatch(page,/data-action="live-refresh"|data-live="feed"/);
  assert.match(w.node('#live-results').innerHTML,/class="scan-game panel"/);
  assert.equal(w.eval('live.seq'),0);
  await assert.rejects(w.eval("P.request('./api/live-games',()=>{throw Error('unexpected network call')})"),/offline download/);
});
function injectLiveSnapshot(w){
  w.eval(`location.hash='#live';live.demo=false;
    var data={status:'ready',nextScan:Date.now()+300000,lastScan:Date.now(),books:{SportyBet:{fixtures:2},Bet9ja:{fixtures:3}},
      opportunities:[{id:'game-1',group:'game',event:'Example match',market:'Full-time goals · 2.5',sport:'Football',
        start:new Date(Date.now()+3600000).toISOString(),updated:Date.now(),supported:true,legs:[
          {book:'SportyBet',name:'Over 2.5',odds:'2.2',max:'',updated:Date.now()},
          {book:'Bet9ja',name:'Under 2.5',odds:'2.1',max:'',updated:Date.now()}
        ]}]};
    applyLiveSnapshot(P.normalizeLiveGames(data));render();`);
}
test('Two-book scanner reloads the server snapshot before calculator handoff',async()=>{
  const w=openWorkspace(new Map(),'https:');
  injectLiveSnapshot(w);
  const click=()=>w.listeners.get('click')({target:{closest:()=>({dataset:{action:'live-open',value:'game-1'}})}});
  assert.match(w.node('#live-results').innerHTML,/SportyBet<\/strong><small>2 upcoming fixtures/);
  assert.match(w.node('#live-results').innerHTML,/Bet9ja<\/strong><small>3 upcoming fixtures/);
  assert.doesNotMatch(w.node('#main').innerHTML,/BetKing/);
  assert.match(w.node('#live-results').innerHTML,/data-action="live-open"/);
  w.eval("P.request=async()=>data;data.opportunities[0].legs[0].odds='2.15'");
  await click();
  assert.equal(w.eval("location.hash"),'#live');
  assert.match(w.node('#toast').textContent,/Odds changed/);
  await click();
  assert.equal(w.eval("state.rows[0].book"),'SportyBet');
  assert.equal(w.eval("state.rows[0].odds"),'2.15');
  assert.equal(w.eval("state.rows[1].book"),'Bet9ja');
  assert.equal(w.eval("state.event"),'Example match · Full-time goals · 2.5');
  assert.equal(w.eval('state.coverage'),false);
});
test('Scanner hides candidates with zero rounded profit or expired prices',()=>{
  const w=openWorkspace(new Map(),'https:');
  injectLiveSnapshot(w);
  w.eval("state.budget='2';data.opportunities[0].legs.forEach(l=>l.odds='2.001');applyLiveSnapshot(P.normalizeLiveGames(data));renderLive()");
  assert.match(w.node('#live-results').innerHTML,/Scan complete — no qualifying opportunities/);
  assert.doesNotMatch(w.node('#live-results').innerHTML,/data-action="live-open"/);
  w.eval("data.opportunities[0].updated=0;applyLiveSnapshot(P.normalizeLiveGames(data));renderLive()");
  assert.match(w.node('#live-results').innerHTML,/Quotes are stale/);
});
test('Hosted scanner requests the real endpoint and pauses on quota state',async()=>{
  const w=openWorkspace(new Map(),'https:');
  assert.equal(w.eval('live.demo'),false);
  w.eval("location.hash='#live';render()");
  const requests=[];
  w.ctx.fetchSnapshot=async path=>{
    requests.push(path);
    return {status:'quota_paused',nextScan:Date.now()+300000,lastScan:null,books:{},opportunities:[]};
  };
  w.eval('P.request=fetchSnapshot;document.hidden=true;scanVisibleLive()');
  assert.deepEqual(requests,[]);
  w.eval('document.hidden=false;scanVisibleLive();scanVisibleLive()');
  await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(requests,['./api/live-games']);
  assert.match(w.node('#live-results').innerHTML,/Free quota paused/);
  assert.match(w.node('#live-results').innerHTML,/Next eligible refresh/);
});
