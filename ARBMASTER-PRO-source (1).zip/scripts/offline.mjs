import {readFileSync,writeFileSync} from 'node:fs';
const root=new URL('../dist/',import.meta.url);
const read=name=>readFileSync(new URL(name,root),'utf8');
const svg=Buffer.from(read('icon.svg')).toString('base64');
let out=read('index.html').replace(/^<link rel="(?:manifest|apple-touch-icon)"[^>]+>\n/gm,'').replace('./icon.svg','data:image/svg+xml;base64,'+svg).replace('<link rel="stylesheet" href="./style.css">',()=>'<style>'+read('style.css')+'</style>');
out=out.replace(/<script defer src="\.\/(.*?)"><\/script>/g,'').replace('</body>',()=>['math.js','market.js','provider.js','app.js'].map(name=>'<script>'+read(name).replace(/<\/script/gi,'<\\/script')+'</script>').join('\n')+'\n</body>');
writeFileSync(new URL('arbmaster-pro-offline.html',root),out);
