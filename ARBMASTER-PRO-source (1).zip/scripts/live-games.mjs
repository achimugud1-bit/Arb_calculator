import {randomUUID} from 'node:crypto';
import {readFile,rename,writeFile} from 'node:fs/promises';
import '../dist/math.js';

const M=globalThis.ArbMath;
const BOOKS=['SportyBet','Bet9ja'];
const FIVE_MINUTES=300000;
const UTC_DAY=86400000;
const MAX_CALLS_PER_DAY=7;
const MAX_CALLS_PER_MONTH=217;
const records=value=>value&&typeof value==='object'&&!Array.isArray(value);
const named=value=>typeof value==='string'&&value.trim();
const date=value=>typeof value==='string'?Date.parse(value):NaN;
const identity=value=>typeof value==='string'||typeof value==='number';

function marketDefinition(m){
  if(m?.sportId!==10||m.playerProp!==false||m.period!=='fulltime'||!Array.isArray(m.outcomes)||!identity(m.marketId))return null;
  const name=String(m.marketName).trim().toLowerCase();
  const result=m.marketType==='1x2'&&name==='full time result'&&m.handicap===0;
  const total=m.marketType==='totals'&&name==='over under full time'&&Number.isFinite(m.handicap)&&m.handicap>=0.5&&m.handicap%1===0.5;
  if(!result&&!total)return null;
  const required=result?['1','x','2']:['over','under'];
  if(m.outcomes.some(o=>!identity(o?.outcomeId)||!named(o.outcomeName)))return null;
  const outcomes=m.outcomes.map(o=>[String(o.outcomeName).toLowerCase(),String(o.outcomeId)]);
  if(outcomes.length!==required.length||new Set(outcomes.map(([,id])=>id)).size!==required.length||
    required.some(side=>outcomes.filter(([label])=>label===side).length!==1))return null;
  return {id:String(m.marketId),label:result?'Full-time result':'Full-time goals · '+m.handicap,
    outcomes:required.map(side=>({id:outcomes.find(([label])=>label===side)[1],
      name:result?{1:'Home win',x:'Draw',2:'Away win'}[side]:(side==='over'?'Over ':'Under ')+m.handicap}))};
}

function fixtureMap(rows){
  const fixtures=new Map();
  for(const row of rows){
    if(!named(row?.fixtureId))continue;
    // An ambiguous duplicate must never overwrite another fixture.
    fixtures.set(row.fixtureId,fixtures.has(row.fixtureId)?null:row);
  }
  return fixtures;
}
function readyFixture(row,now){
  return row?.sportId===10&&row.statusId===0&&(!row.statusName||row.statusName==='Pre-Game')&&
    row.hasOdds===true&&!row.trueStartTime&&!row.trueEndTime&&date(row.startTime)>now&&
    identity(row.tournamentId)&&identity(row.participant1Id)&&identity(row.participant2Id)&&
    row.participant1Id!==row.participant2Id;
}
function readyBook(row,slug){
  const book=row.bookmakerOdds?.[slug];
  return book?.bookmakerIsActive===true&&book.suspended===false&&book.staleOdds!==true?book:null;
}
function selection(market,outcome,book,now){
  if(market?.marketActive!==true)return null;
  const quote=market.outcomes?.[outcome.id]?.players?.['0'];
  if(quote?.active!==true||quote.staleOdds===true||quote.exchangeMeta!=null)return null;
  // Change times cannot prove a quote was rechecked. Use them only as a conservative age bound.
  const updated=date(quote.changedAt);
  if(!Number.isFinite(updated)||updated>now+5000||now-updated>=FIVE_MINUTES)return null;
  const reported=date(quote.bookmakerChangedAt);
  if(quote.bookmakerChangedAt!=null&&(!Number.isFinite(reported)||reported>now+5000||now-reported>=FIVE_MINUTES))return null;
  try{
    const odds=String(quote.price),value=M.odds(odds);
    const max=quote.limit==null||quote.currency!=='NGN'?'':String(quote.limit);
    if(max&&M.parse(max)<M.Q)return null;
    return {name:outcome.name,book,odds,max,value,updated:Number.isFinite(reported)?Math.min(updated,reported):updated};
  }catch{return null}
}

export function scanRawOdds({boards,slugs,markets,participants={},now=Date.now()}){
  const definitions=markets.map(marketDefinition).filter(Boolean);
  const fixtures=boards.map(fixtureMap);
  const hasQuotes=(book,definition)=>definition.outcomes.some(outcome=>selection(book?.markets?.[definition.id],outcome,'',now));
  const books=Object.fromEntries(BOOKS.map((book,i)=>[book,{fixtures:[...fixtures[i].values()].filter(row=>
    readyFixture(row,now)&&definitions.some(definition=>hasQuotes(readyBook(row,slugs[i]),definition))).length}]));
  const opportunities=[];
  let matched=0;
  for(const [id,left] of fixtures[0]){
    const right=fixtures[1].get(id);
    if(!readyFixture(left,now)||!readyFixture(right,now)||['participant1Id','participant2Id','tournamentId','startTime'].some(key=>left[key]!==right[key]))continue;
    const home=named(left.participant1Name)||named(right.participant1Name)||named(participants[left.participant1Id]);
    const away=named(left.participant2Name)||named(right.participant2Name)||named(participants[left.participant2Id]);
    const selectedBooks=[readyBook(left,slugs[0]),readyBook(right,slugs[1])];
    if(!selectedBooks.every(Boolean)||!home||!away)continue;
    let fixtureMatched=false;
    for(const market of definitions){
      const groups=market.outcomes.map(outcome=>selectedBooks.map((book,i)=>selection(book.markets?.[market.id],outcome,BOOKS[i],now)).filter(Boolean));
      if(groups.some(group=>!group.length)||new Set(groups.flat().map(leg=>leg.book)).size!==2)continue;
      fixtureMatched=true;
      const combinations=groups.reduce((prior,group)=>prior.flatMap(legs=>group.map(leg=>[...legs,leg])),[[]]);
      for(const legs of combinations){
        if(new Set(legs.map(leg=>leg.book)).size!==2)continue;
        const gap=M.Q-M.add(legs.map(leg=>M.div(M.Q,leg.value)));
        if(gap<=0n)continue;
        const group=id+'-'+market.id;
        opportunities.push({id:group+'-'+legs.map(leg=>BOOKS.indexOf(leg.book)).join(''),group,event:home+' vs '+away,sport:'Football',
          league:left.tournamentName||right.tournamentName||'',market:market.label,start:left.startTime,phase:'Pre-match',
          updated:Math.min(...legs.map(leg=>leg.updated)),gap:M.str(gap*100n,24,true),supported:true,
          legs:legs.map(({name,book,odds,max,updated})=>({name,book,odds,max,updated}))});
      }
    }
    if(fixtureMatched)matched++;
  }
  return {books,matched,opportunities};
}

function responseRows(data){
  if(Array.isArray(data))return data;
  if(records(data)&&named(data.fixtureId))return [data];
  throw Error('Unexpected OddsPapi fixture response.');
}

export function createLiveGames({apiKey,slugs=[],tournaments=['17','8'],quotaPath='.arbmaster-odds-quota.json',
  fetcher=fetch,now=Date.now,wait=ms=>new Promise(resolve=>setTimeout(resolve,ms))}={}){
  const configured=Boolean(apiKey)&&slugs.length===2&&new Set(slugs).size===2&&slugs.every(s=>/^[a-z0-9_+-]{2,64}$/i.test(s))&&
    tournaments.length>0&&tournaments.length<=5&&tournaments.every(id=>/^\d+$/.test(id));
  let current=null,pending,nextScan=0,state='coverage_unverified',catalog,participants,lastCall=null;
  const response=(status,extra={})=>({status,lastScan:current?.lastScan??null,nextScan:Number.isFinite(nextScan)?nextScan:null,
    books:current?.books??{},matched:current?.matched??0,opportunities:current?.opportunities??[],...extra});

  async function reserve(){
    let used=[];
    try{
      used=JSON.parse(await readFile(quotaPath,'utf8'));
      if(!Array.isArray(used)||used.some(value=>!Number.isSafeInteger(value)))throw Error();
    }catch(error){
      if(error.code!=='ENOENT')throw Object.assign(Error('Quota ledger inaccessible; no odds requests were made.'),{state:'quota_unavailable'});
    }
    const clock=now(),today=Math.floor(clock/UTC_DAY)*UTC_DAY;
    used=used.filter(value=>value>clock-31*UTC_DAY);
    if(used.length>=MAX_CALLS_PER_MONTH||used.filter(value=>value>=today).length>=MAX_CALLS_PER_DAY){
      nextScan=Math.max(today+UTC_DAY,used.length>=MAX_CALLS_PER_MONTH?Math.min(...used)+31*UTC_DAY:0);
      throw Object.assign(Error('Free odds request limit reached.'),{state:'quota_paused'});
    }
    const temporary=quotaPath+'.'+randomUUID()+'.tmp';
    await writeFile(temporary,JSON.stringify([...used,clock]),{mode:0o600,flag:'wx'});
    await rename(temporary,quotaPath);
  }

  async function provider(path,params){
    // The bulk route requires at least one second between calls for the same key.
    if(lastCall!==null)await wait(Math.max(0,1100-(now()-lastCall)));
    await reserve();
    lastCall=now();
    const url=new URL('/v4/'+path,'https://api.oddspapi.io');
    for(const [name,value] of Object.entries({...params,apiKey,language:'en'}))url.searchParams.set(name,value);
    const result=await fetcher(url,{redirect:'error',headers:{Accept:'application/json'},signal:AbortSignal.timeout(9000)});
    if(result.status===429){
      const header=result.headers?.get('Retry-After');
      const seconds=header&&/^\d+$/.test(header)?Number(header):NaN;
      nextScan=Math.max(now()+FIVE_MINUTES,Number.isFinite(seconds)?now()+seconds*1000:date(header)||0);
      throw Object.assign(Error('OddsPapi has paused requests.'),{state:'quota_paused'});
    }
    if([401,403].includes(result.status))throw Object.assign(Error('OddsPapi did not authorize this key or endpoint.'),{state:'access_unavailable'});
    if(!result.ok)throw Error('OddsPapi request failed.');
    return result.json();
  }

  async function scan(){
    if(!configured)return response('unconfigured',{message:'No verified free feed. Configure an authorized OddsPapi key and the two confirmed Nigerian bookmaker slugs.'});
    if(pending)return pending;
    if(now()<nextScan)return response(state);
    pending=(async()=>{
      nextScan=now()+FIVE_MINUTES;
      try{
        if(!catalog||now()-catalog.updated>=UTC_DAY){
          const markets=await provider('markets',{});
          if(!Array.isArray(markets)||!markets.some(marketDefinition))throw Error('No supported markets in provider dictionary.');
          catalog={updated:now(),markets};
        }
        const boards=[];
        for(const bookmaker of slugs){
          boards.push(responseRows(await provider('odds-by-tournaments',{tournamentIds:tournaments.join(','),bookmaker,verbosity:'3'})));
        }
        if(boards.some(board=>board.some(row=>readyFixture(row,now())&&(!named(row.participant1Name)||!named(row.participant2Name))))&&
          (!participants||now()-participants.updated>=UTC_DAY)){
          const names=await provider('participants',{sportId:'10'});
          if(!records(names))throw Error('Unexpected OddsPapi participants response.');
          participants={updated:now(),names};
        }
        const scannedAt=now();
        current={lastScan:scannedAt,...scanRawOdds({boards,slugs,markets:catalog.markets,participants:participants?.names,now:scannedAt})};
        state=current.matched?'ready':'coverage_unverified';
        nextScan=scannedAt+FIVE_MINUTES;
        return response(state);
      }catch(error){
        state=error.state??'unavailable';
        if(state==='access_unavailable'||state==='quota_unavailable')nextScan=Infinity;
        return response(state);
      }
    })();
    try{return await pending}finally{pending=null}
  }
  return scan;
}
