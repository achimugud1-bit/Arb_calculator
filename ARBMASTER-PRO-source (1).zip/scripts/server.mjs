import {createServer} from 'node:http';
import {createLiveGames} from './live-games.mjs';
import {readFile} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {extname,resolve,sep} from 'node:path';
const root=fileURLToPath(new URL('../dist/',import.meta.url));
const regions=new Set(['us','us2','uk','eu','au']);
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};
export function createOddsAdapter({apiKey,fetcher=fetch,now=Date.now}={}){
  const cache=new Map(),pending=new Map();
  return async url=>{
    if(!apiKey)return {status:503,data:{error:'Live odds credentials are unconfigured.'}};
    const sports=url.pathname==='/api/sports',sport=url.searchParams.get('sport'),region=url.searchParams.get('region');
    if(!sports&&url.pathname!=='/api/odds')return {status:404,data:{error:'Unsupported route.'}};
    if(!sports&&(!sport||!/^([a-z0-9_]{3,65})$/.test(sport)||!regions.has(region)))return {status:400,data:{error:'Invalid sport or region.'}};
    const key=sports?'sports':sport+' '+region,old=cache.get(key);
    if(old&&old.expiry>now())return old.value;
    if(pending.has(key))return pending.get(key);
    if(pending.size>=5)return {status:429,data:{error:'Provider is busy.'}};
    const req=(async()=>{
      const endpoint=new URL('https://api.the-odds-api.com/v4/sports/'+(sports?'':sport+'/odds/'));
      endpoint.searchParams.set('apiKey',apiKey);
      if(!sports){endpoint.searchParams.set('regions',region);endpoint.searchParams.set('markets','h2h');endpoint.searchParams.set('oddsFormat','decimal');}
      try{
        const r=await fetcher(endpoint,{signal:AbortSignal.timeout(9000)});
        if(r.status===429)return {status:429,data:{error:'Provider quota or rate limit reached.'}};
        if(!r.ok)return {status:502,data:{error:'Odds provider rejected the request.'}};
        const data=await r.json();
        if(!Array.isArray(data))return {status:502,data:{error:'Unexpected provider response.'}};
        const value={status:200,data};
        if(cache.size>=100)cache.delete(cache.keys().next().value);
        cache.set(key,{value,expiry:now()+(sports?900000:30000)});
        return value;
      }catch{return {status:502,data:{error:'Odds provider unavailable.'}}}
    })();
    pending.set(key,req);
    try{return await req}finally{pending.delete(key)}
  };
}
export function createAppServer({odds=createOddsAdapter(),liveGames=createLiveGames()}={}){
  return createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','no-referrer');
    if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
    try{
      const url=new URL(req.url,'http://localhost');
      if(url.pathname.startsWith('/api/')){
        if(url.pathname==='/api/live-games'){
          if(req.headers?.['sec-fetch-site']==='cross-site'){res.writeHead(403);return res.end();}
          const body=req.method==='HEAD'?undefined:JSON.stringify(await liveGames());
          res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
          return res.end(body);
        }
        const {status,data}=await odds(url);
        res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(req.method==='HEAD'?undefined:JSON.stringify(data));
      }
      const file=resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
      if(!file.startsWith(root.endsWith(sep)?root:root+sep))throw Error();
      const data=await readFile(file);
      res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream'});res.end(req.method==='HEAD'?undefined:data);
    }catch{res.writeHead(404);res.end('Not found');}
  });
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){
  const odds=createOddsAdapter({apiKey:process.env.ODDS_API_KEY});
  const liveGames=createLiveGames({
    apiKey:process.env.ODDSPAPI_API_KEY,
    slugs:(process.env.ODDSPAPI_NG_BOOKMAKERS||'').split(',').map(slug=>slug.trim()),
    tournaments:(process.env.ODDSPAPI_TOURNAMENT_IDS||'17,8').split(',').map(id=>id.trim()),
    quotaPath:process.env.ODDSPAPI_QUOTA_PATH
  });
  createAppServer({odds,liveGames}).listen(Number(process.env.PORT||4173),process.env.HOST||'127.0.0.1',
    ()=>console.log('ARBMASTER PRO server ready.'));
}
