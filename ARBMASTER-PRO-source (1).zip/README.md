# ARBMASTER PRO

A dependency-free, phone-first workspace with four sections: Arbitrage Calculator, Live Games, Tracker, and Money Tracker. The calculator and both trackers work offline and save records in the active browser profile. No account or payment integration is used.

## Run and test

```sh
npm test
npm run build
npm start
```

Open http://127.0.0.1:4173. On an HTTPS origin, supported browsers can install and cache the app. The standalone `dist/arbmaster-pro-offline.html` bundles the app in a single file. Local HTML storage behavior varies by browser and phone. Export records if you need a backup.

## Free SportyBet and Bet9ja scanner

The standalone HTML uses demo data. Real scanning requires the included Node server and an authorized free OddsPapi key. OddsPapi publicly lists SportyBet. Actual Bet9ja coverage on the free plan, the Nigerian regional slugs, and the live response remain to be verified. No paid provider is needed by the application.

1. Obtain a free key if available and use OddsPapi's [bookmaker catalog](https://oddspapi.io/en/docs/get-bookmakers) to confirm the Nigerian slugs for SportyBet and Bet9ja. Check the plan allows using the odds in this private app. If either book is missing, leave the feed unconfigured.
2. Supply the key as the server environment variable `ODDSPAPI_API_KEY`. Supply the confirmed slugs, in SportyBet then Bet9ja order, as `ODDSPAPI_NG_BOOKMAKERS`.
3. Run `npm start`. That serves locally at port 4173. For a phone on the same trusted Wi-Fi network, start with `HOST=0.0.0.0 npm start` and open `http://<your-computer-LAN-IP>:4173/#live` on the phone. Use one Node process on a trusted private network and keep the port off the public internet.

The first scan uses the [market dictionary](https://oddspapi.io/docs/get-markets) plus one [bulk tournament-odds request](https://oddspapi.io/en/docs/get-odds-by-tournaments) per book. If team names are absent it obtains the participant catalog. The default is Premier League and La Liga (`ODDSPAPI_TOURNAMENT_IDS=17,8`). Set up to five documented football tournament IDs. Requests are counted before fetch, limited to seven per UTC day and 217 per rolling 31 days, and shared across browsers. The ledger persists in `.arbmaster-odds-quota.json`, or at `ODDSPAPI_QUOTA_PATH`. Preserve that file across restarts. Use a dedicated key because calls made by other applications with the same key cannot be counted here.

Live Games serves a shared snapshot and updates it at most every five minutes while a viewer is present and quota allows. Older or suspended quotes are excluded. Provider change timestamps are used as a conservative age bound, so an unchanged quote may be excluded even if still offered. The two books are matched using identical fixture and market IDs with corroborating fixture metadata. Only documented full-time 1X2 and half-line goal totals are enabled. Corners, shots, fouls and in-play require verified raw coverage and settlement mappings before activation. Estimates use whole-naira stakes and the existing calculator budget.

No available provider quotes or real opportunities are simulated in the live view. Testing uses synthetic fixtures in documented response formats. Start with the free coverage check before relying on the scanner.

## Calculation policies

Fixed-point arithmetic uses 24 decimal places. Arbitrage uses integer stake increments and rounds gross and net receipts down to the currency minor unit. The allocator finds a feasible maximum minimum payout, then compares candidate stake vectors for worst-case net profit, payout spread and capital use. Small profitable-price searches examine every feasible binding payout threshold. Larger searches compare thresholds around the equalization and constraint boundaries. Global maximin optimality is not claimed outside exhaustive search. Losing-price calculations display the allocation with the highest feasible minimum payout to illustrate the quoted prices.

The calculator assumes one mutually exclusive winner and includes user-entered compatibility checks. Markets involving pushes, voids, overlapping selections, or complex settlements fall outside this model. The tracker records actual payouts and fees by bet. No FX conversion is performed.

Use **Lock a stake** to enter an exact whole-unit amount for one or more outcomes and calculate the remaining stakes. Leave the budget blank to calculate total capital from the locked amount, or enter a limit to cap spending. **Copy** beside an outcome copies only its whole-number stake.
